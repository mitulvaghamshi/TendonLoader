CREATE TABLE Exercise (
    "id"            INTEGER PRIMARY KEY AUTOINCREMENT,
    "user_id"       TEXT NOT NULL,
    "pain_score"    REAL NOT NULL,
    "datetime"      TEXT NOT NULL,
    "tolerable"     TEXT NOT NULL,
    "completed"     INTEGER NOT NULL,
    "progressor_id" TEXT NOT NULL,
    "mvc_value"     REAL,
    "data"          VARCHAR NOT NULL
);
