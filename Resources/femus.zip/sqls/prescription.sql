CREATE TABLE Prescription (
    "id"            INTEGER PRIMARY KEY AUTOINCREMENT,
    "exercise_id"   INTEGER REFERENCES Exercise("id"),
    "user_id"       TEXT NOT NULL,
    "reps"          INTEGER NOT NULL,
    "sets"          INTEGER NOT NULL,
    "set_rest"      INTEGER NOT NULL,
    "hold_time"     INTEGER NOT NULL,
    "rest_time"     INTEGER NOT NULL,
    "mvc_duration"  INTEGER NOT NULL,
    "target_load"   REAL NOT NULL
);
